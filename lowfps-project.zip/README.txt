КАК ПОЛУЧИТЬ МОД (.jar), без установки программ:
1. Зарегистрируйся на github.com (бесплатно).
2. Нажми "+" -> New repository -> назови lowfps -> Create.
3. Нажми "uploading an existing file", перетащи ВСЕ файлы из этой папки
   (включая скрытую папку .github) -> Commit changes.
   Если .github не перетаскивается: Add file -> Create new file, имя
   .github/workflows/build.yml и вставь содержимое оттуда.
4. Вкладка Actions -> дождись зелёной галочки (3-5 минут).
5. Открой запуск -> внизу Artifacts -> скачай lowfps-mod -> внутри .jar.
6. Нужны: Fabric Loader для 1.21.4 + Fabric API. Положи .jar в папку mods.
