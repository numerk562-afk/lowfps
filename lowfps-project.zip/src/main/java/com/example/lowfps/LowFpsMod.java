package com.example.lowfps;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.ParticlesMode;

public class LowFpsMod implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientLifecycleEvents.CLIENT_STARTED.register(client -> {
            GameOptions o = client.options;

            o.getViewDistance().setValue(2);
            o.getSimulationDistance().setValue(5);
            o.getEntityDistanceScaling().setValue(0.5);

            o.getGraphicsMode().setValue(GraphicsMode.FAST);
            o.getParticles().setValue(ParticlesMode.MINIMAL);
            o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
            o.getEntityShadows().setValue(false);
            o.getAo().setValue(false);
            o.getBiomeBlendRadius().setValue(0);
            o.getMipmapLevels().setValue(0);

            o.getBobView().setValue(false);
            o.getDamageTiltStrength().setValue(0.0);
            o.getFovEffectScale().setValue(0.0);
            o.getDistortionEffectScale().setValue(0.0);
            o.getMenuBackgroundBlurriness().setValue(0);

            o.getEnableVsync().setValue(false);
            o.getMaxFps().setValue(260);

            o.write();
        });
    }
}
